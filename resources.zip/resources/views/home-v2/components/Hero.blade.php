{{-- Hero Section Component --}}
<section class="hero-v2">
    {{-- Section mobile uniquement : Email + Logo + Map --}}
    <div class="hero-mobile-header">
        <div class="hero-mobile-email">
            <a href="mailto:INFOGOEXPLORIA@GMAIL.COM">INFOGOEXPLORIA@GMAIL.COM</a>
        </div>
        <div class="hero-mobile-logo-container">
            <a href="#" class="hero-mobile-logo">
                <img src="{{ asset('logo.png') }}" alt="GO EXPLORIA" class="hero-mobile-logo-img">
                <!-- <div class="logo-text">
                    <div class="logo-exploria">GO EXPLORIA</div>
                    <div class="logo-location">QUÉBEC, CANADA</div>
                </div> -->
            </a>
            <img src="{{ asset('header_info/map2.png') }}" alt="Map" class="hero-mobile-map">
        </div>
    </div>
    
    <div class="hero-content">
        <div class="hero-text">
            <h1 class="hero-title">
                <span class="hero-main">GO EXPLORIA</span>
            </h1>
        </div>
        
        <div class="hero-search">
            <div class="search-container">
                <div class="search-wrapper">
                    <svg class="search-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="11" cy="11" r="8"></circle>
                        <path d="m21 21-4.35-4.35"></path>
                    </svg>
                    <input 
                        type="text" 
                        class="search-input" 
                        placeholder="Rechercher une activité, une destination..."
                        aria-label="Rechercher"
                    >
                </div>
                <div class="search-brand">
                    <img src="{{ asset('logo.png') }}" alt="PLAN-N-GO" class="plan-n-go-logo">
                </div>
            </div>
        </div>
        
        <button class="hero-scroll-btn" aria-label="Défiler vers le bas">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M12 5v14"></path>
                <path d="m19 12-7 7-7-7"></path>
            </svg>
        </button>
    </div>
</section>
